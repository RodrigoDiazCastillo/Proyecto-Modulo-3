// --- PROYECTO MÓDULO 3: APLICACIÓN DE CONSOLA ---

// 1. Definimos las variables globales necesarias [cite: 55]
// Usamos un arreglo para la lista y objetos para cada gasto [cite: 17, 30]
let listaDeGastos = []; 

// 2. Función para agregar un gasto (Modularización) [cite: 32, 74]
function agregarGasto() {
    let nombre = prompt("¿Qué compraste?"); // [cite: 23, 46]
    let monto = Number(prompt("¿Cuánto costó?")); // [cite: 56, 59]

    // Validación: Controlamos que el usuario ingrese un número válido [cite: 35]
    if (isNaN(monto) || monto <= 0) {
        alert("Por favor, ingresa un número válido mayor a cero."); // [cite: 49]
        return;
    }

    // Creamos un objeto para organizar los datos [cite: 79, 81]
    const nuevoGasto = {
        descripcion: nombre,
        precio: monto
    };

    listaDeGastos.push(nuevoGasto); // Guardamos el objeto en el arreglo [cite: 34]
    console.log("Gasto guardado con éxito."); 
}

// 3. Función para mostrar la lista usando un bucle [cite: 27, 68]
function mostrarGastos() {
    if (listaDeGastos.length === 0) {
        console.log("La lista está vacía.");
        return;
    }

    console.log("--- Tus Gastos ---");
    // Recorremos el arreglo de objetos con un ciclo for [cite: 33, 84]
    for (let i = 0; i < listaDeGastos.length; i++) {
        console.log(`${i + 1}. ${listaDeGastos[i].descripcion} - $${listaDeGastos[i].precio}`);
    }
}

// 4. Función para la operación matemática (Suma total) [cite: 25, 59]
function calcularTotal() {
    let total = 0;
    for (let i = 0; i < listaDeGastos.length; i++) {
        total = total + listaDeGastos[i].precio; // Sumatoria básica [cite: 75]
    }
    alert("El total de tus gastos es: $" + total);
}

// 5. Bucle principal de la aplicación [cite: 27, 33]
function iniciarPrograma() {
    let continuar = true;

    while (continuar) {
        let opcion = prompt(
            "Selecciona una opción:\n" +
            "1. Agregar Gasto\n" +
            "2. Ver Lista\n" +
            "3. Ver Total\n" +
            "4. Salir"
        );

        switch (opcion) { // Estructura condicional [cite: 61]
            case "1":
                agregarGasto();
                break;
            case "2":
                mostrarGastos();
                break;
            case "3":
                calcularTotal();
                break;
            case "4":
                alert("Cerrando aplicación...");
                continuar = false; // Detiene el bucle [cite: 68]
                break;
            default:
                alert("Opción no válida.");
        }
    }
}

// Ejecutamos el programa [cite: 96]
iniciarPrograma();