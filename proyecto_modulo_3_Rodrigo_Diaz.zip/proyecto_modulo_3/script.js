// --- PROYECTO MÓDULO 3: APLICACIÓN DE CONSOLA ---

// 1. Definimos las variables globales necesarias
// Usamos un arreglo para la lista y objetos para cada gasto
let listaDeGastos = []; 

// 2. Función para agregar un gasto (Modularización)
function agregarGasto() {
    let nombre = prompt("¿Qué compraste?");
    let monto = Number(prompt("¿Cuánto costó?"));

    // Validación: Controlamos que el usuario ingrese un número válido
    if (isNaN(monto) || monto <= 0) {
        alert("Por favor, ingresa un número válido mayor a cero.");
        return;
    }

    // Creamos un objeto para organizar los datos
    const nuevoGasto = {
        descripcion: nombre,
        precio: monto
    };

    listaDeGastos.push(nuevoGasto); // Guardamos el objeto en el arreglo
    console.log("Gasto guardado con éxito."); 
}

// 3. Función para mostrar la lista usando un bucle
function mostrarGastos() {
    if (listaDeGastos.length === 0) {
        console.log("La lista está vacía.");
        return;
    }

    console.log("--- Tus Gastos ---");
    // Recorremos el arreglo de objetos con un ciclo for
    for (let i = 0; i < listaDeGastos.length; i++) {
        console.log(`${i + 1}. ${listaDeGastos[i].descripcion} - $${listaDeGastos[i].precio}`);
    }
}

// 4. Función para la operación matemática (Suma total)
function calcularTotal() {
    let total = 0;
    for (let i = 0; i < listaDeGastos.length; i++) {
        total = total + listaDeGastos[i].precio; // Sumatoria básica
    }
    alert("El total de tus gastos es: $" + total);
}

// 5. Bucle principal de la aplicación
function iniciarPrograma() {
    let continuar = true;

    while (continuar) {
        let opcion = prompt(
            "Selecciona una opción:\n" +
            "1. Agregar Gasto\n" +
            "2. Ver Lista\n" +
            "3. Ver Total\n" +
            "4. Salir"
        );

        switch (opcion) { // Estructura condicional
            case "1":
                agregarGasto();
                break;
            case "2":
                mostrarGastos();
                break;
            case "3":
                calcularTotal();
                break;
            case "4":
                alert("Cerrando aplicación...");
                continuar = false; // Detiene el bucle
                break;
            default:
                alert("Opción no válida.");
        }
    }
}

// Ejecutamos el programa
iniciarPrograma();